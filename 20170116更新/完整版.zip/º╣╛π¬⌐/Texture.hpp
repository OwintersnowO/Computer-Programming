#ifndef Texture_hpp
#define Texture_hpp

#include "SDL.h"
#include "SDL_image.h"
#include <iostream>

class iTexture {
protected:
    SDL_Texture* tIMG = NULL;
    SDL_Rect rRect;
    SDL_Rect *Clip;
    SDL_Point RotateCenter;
    int TotalClip;

public:
    iTexture(){}
    iTexture(std::string, SDL_Renderer*);
    iTexture(std::string, SDL_Renderer*, int, int);
    ~iTexture();

    void Initialize(std::string, SDL_Renderer*, int);
    void Load(std::string, SDL_Renderer*);
    
    void Show(SDL_Renderer*, int, int, int, int);
    void Show(SDL_Renderer*, int, int, int, int, double, int, int);
    void Show(SDL_Renderer*, int);
    
    void setAlpha(int);
    void setRECT(int, int, int, int);
    void setClip();
    void setClip(int, int, int);
    int getTotalClip();
    SDL_Texture* getTexture();
    SDL_Rect* getClip();
};

#endif /* Texture_hpp */
