#ifndef Button_hpp
#define Button_hpp

#include <SDL.h>
#include <SDL_image.h>
#include "Texture.hpp"
#include <iostream>

enum iButtonSprite {
    MOUSE_OUT = 0,
    MOUSE_OVER_MOTION = 1,
    MOUSE_DOWN = 2,
    MOUSE_UP = 3,
    BUTTON_SPRITE_TOTAL = 4,
    MOUSE_RIGHT = 5
};

class iButton : public iTexture {
private:
    iButtonSprite bCurrentState = MOUSE_OUT;
    
public:
    iButton(std::string fileName, SDL_Renderer* rR, int w, int h) : iTexture(fileName, rR, w, h) {}
    
    void handleEvent( SDL_Event* e );
    void Show(SDL_Renderer*, int, int, int, int);
    void buttonReset();
    void buttonAdjust();
    int getCurrentState();
};

#endif
