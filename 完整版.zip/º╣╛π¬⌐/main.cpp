#include <SDL.h>
#include "Core.hpp"

int main(int argc, char * argv[]) {
    iCore iGroc;
    iGroc.mainLoop();

    return 0;
}
