#include "Texture.hpp"
#include "Extern.hpp"

/* ********************* Constructor *********************** */



iTexture::iTexture(std::string fileName, SDL_Renderer* rR) {                                                        // for whole screen
    tIMG = LoadTexture(fileName, rR);
}


iTexture::iTexture(std::string fileName, SDL_Renderer* rR, int w, int h) {                            // for not whole screen
    tIMG = LoadTexture(fileName, rR);
    setClip(4, w, h);
}

iTexture::iTexture(std::string fileName, SDL_Renderer* rR, int TotalClips) {                                        // for animation
    Initialize( fileName, rR, TotalClip ) ;
}

iTexture::~iTexture() {
    SDL_DestroyTexture(tIMG);
}
/* ********************* Constructor *********************** */

/* ********************* Initialize ************************ */
void iTexture::Initialize(std::string fileName, SDL_Renderer* rR, int TotalClips){
    tIMG = LoadTexture(fileName, rR);
    TotalClip = TotalClips;
    setClip();
}
/* ********************* Initialize ************************ */

/* ************************* Show ************************** */

void iTexture::Show(SDL_Renderer* rR, int x, int y, int w, int h) {                                             // for simple show
    setRECT(x, y, w, h);
    SDL_RenderCopyEx(rR, tIMG, NULL, &rRect, 0.0, NULL, SDL_FLIP_NONE);
}

void iTexture::Show(SDL_Renderer* rR, int x, int y, int w, int h, double angle, int centerx, int centery) {     // for rotate show
    setRECT(x, y, w, h);
    RotateCenter.x = centerx;
    RotateCenter.y = centery;
    SDL_RenderCopyEx(rR, tIMG, NULL, &rRect, angle, &RotateCenter, SDL_FLIP_NONE);
}

void iTexture::Show(SDL_Renderer* rR, int currentSprite) {                          // for iButton show
    SDL_Rect &currentClip = Clip[currentSprite];
    SDL_RenderCopy(rR, tIMG, &currentClip, &rRect);
}
/* ************************* Show ************************** */

void iTexture::SetAlpha(int i) {
    SDL_SetTextureAlphaMod(tIMG, i);
}

/* ******************** Create Texture ********************* */
SDL_Texture* iTexture::LoadTexture (std::string fileName, SDL_Renderer *rR) {
    fileName = fileName + ".png";
    SDL_Texture *Texture = NULL;
    SDL_Surface *Loaded = IMG_Load(fileName.c_str());

    Texture = SDL_CreateTextureFromSurface(rR, Loaded);
    SDL_FreeSurface(Loaded);
    return Texture;
}
/* ******************** Create Texture ********************* */

void iTexture::Load(std::string fileName, SDL_Renderer* rR) {
    tIMG = LoadTexture(fileName, rR);
}

void iTexture::setRECT(int x, int y, int w, int h) {                    // for iTecture
    rRect.x = x;
    rRect.y = y;
    rRect.w = w;
    rRect.h = h;
}

void iTexture::setClip() {                                // for Animation
    Clip = new SDL_Rect [TotalClip];
    for (int i = 0; i < TotalClip; i++){
        Clip[ i ].x = 52;
        Clip[ i ].y = 400*i+47;
        Clip[ i ].w = iExtern::GENIE_WIDTH;
        Clip[ i ].h = iExtern::GENIE_HEIGHT;
    }
}

void iTexture::setClip(int TotalClips, int bW, int bH) {       // for iButton
    Clip = new SDL_Rect [TotalClips];
    for (int i = 0; i < TotalClips; i++){
        Clip[ i ].x = 0;
        Clip[ i ].y = bH*i;
        Clip[ i ].w = bW;
        Clip[ i ].h = bH;
    }
}

int iTexture::getTotalClip() {
    return TotalClip;
}

SDL_Texture* iTexture::getTexture() {
    return tIMG;
}

SDL_Rect* iTexture::getClip() {
    return Clip;
}
