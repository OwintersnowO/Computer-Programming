#ifndef Time_hpp
#define Time_hpp
#include <string>
#include <ctime>

class iTime{
public:
    iTime();
    ~iTime();
    bool SetTimeDigit(int,int);
    void ResetTime();
    int GetTimeDigit(int);
    bool TimeZero();
    void MinusTime(long temp);
    void PlusTime(long temp);

private:
    int hour;
    int minute;
    int second;
};

#endif /* Time_hpp */
