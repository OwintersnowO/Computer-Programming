#include "Time.hpp"

iTime::iTime() {
    ResetTime();
}
iTime::~iTime() {}

bool iTime::SetTimeDigit(int i, int value){
    switch(i){
        case 0:
            hour = hour%10+value*10;
            return true;
        case 1:
            hour = (hour/10)*10+value;
            return true;
        case 2:
            if (value >= 6) {
                return false;
            }
            minute = minute%10+value*10;
            return true;
        case 3:
            minute = (minute/10)*10+value;
            return true;
        case 4:
            if (value >= 6) {
                return false;
            }
            second = second%10+value*10;
            return true;
        case 5:
            second = (second/10)*10+value;
            return true;
        default:
            return false;
    }
    return false;
}

void iTime::ResetTime(){
    hour=0;
    minute=0;
    second=0;
    return ;
}
bool iTime::TimeZero(){
    return (hour==0 && minute==0 && second==0);
}
int iTime::GetTimeDigit(int i){
    switch(i){
        case 0:
            return hour/10;
        case 1:
            return hour%10;
        case 2:
            return minute/10;
        case 3:
            return minute%10;
        case 4:
            return second/10;
        case 5:
            return second%10;
        default:
            return 0;
    }
}
void iTime::MinusTime(long temp){
    second-=temp;
    if(second<0){
        minute-=(60-second)/60;
        second=second%60+60;
    }
    if(minute<0){
        hour-=(60-minute)/60;
        minute=minute%60+60;
    }
    if(hour<0){
        hour=0;
    }
    return ;
}

void iTime::PlusTime(long temp){
    second+=temp;
    if(second>=60){
        minute+=second/60;
        second%=60;
    }
    if(minute>=60){
        hour+=minute/60;
        minute%=60;
    }
    if(hour>99){
        hour=99;
    }
    return ;
}
