#ifndef Genie_hpp
#define Genie_hpp

#include "SDL.h"
#include "SDL_image.h"
#include <SDL_shape.h>
#include <SDL_pixels.h>
#include "Button.hpp"

enum iMood {
    VERTICAL_BOUNCE = 0,
    HORIZONTAL_BOUNCE = 1,
    ROLLING_EYES = 2,
    ANGRY = 3,
    BASKETBALL = 4,
    MOOD_NUM = 5
};

class iGenie {
private:
    SDL_Window* window;
    SDL_Renderer* rR;
    SDL_Event* mainEvent;
    bool quitGenie;
    bool DragMode = false;
    int WindowX = 600;
    int WindowY = 300;
    bool motion;
    iTexture moodPicture[ MOOD_NUM ];
    int mood;
    
    void RollingEyes();
    void CountDown();
    void TrueClock();
    void Timer();
    void Drag(iButton*);
    void RandomMove();
    void Animation();
    void close();

public:
    iGenie(void);
    ~iGenie(void);

    void mainLoop();
};


#endif
