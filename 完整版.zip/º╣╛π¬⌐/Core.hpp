#ifndef Core_hpp
#define Core_hpp

#include "SDL.h"
#include "SDL_image.h"
#include <iostream>

class iCore {
private:
    SDL_Window* window;
    SDL_Renderer* rR;
    SDL_Event* mainEvent;

public:
    iCore(void);
    ~iCore(void);
    SDL_Texture* LoadTexture (std::string , SDL_Renderer*);
    bool quitApp;

    void mainLoop();
    void close();
};

#endif /* Core_hpp */
