#ifndef Button_hpp
#define Button_hpp

#include <SDL.h>
#include <SDL_image.h>
#include "Texture.hpp"
#include <iostream>

enum iButtonSprite {
    MOUSE_OUT = 0,
    MOUSE_OVER_MOTION = 1,
    MOUSE_DOWN = 2,
    MOUSE_UP = 3,
    BUTTON_SPRITE_TOTAL = 4,
    MOUSE_RIGHT = 5
};

class iButton : public iTexture
{
public:
    iButton(std::string fileName, SDL_Renderer* rR, int w, int h) : iTexture(fileName, rR, w, h) {}
    iButton(std::string fileName, SDL_Renderer* rR) : iTexture(fileName, rR) {}

    void handleEvent( SDL_Event* e );
    void setRECT(int, int, int, int);
    void Show(SDL_Renderer*);
    void buttonReset();
    void buttonAdjust();
    int getCurrentState();

private:
    iButtonSprite bCurrentState = MOUSE_OUT;
};

#endif
