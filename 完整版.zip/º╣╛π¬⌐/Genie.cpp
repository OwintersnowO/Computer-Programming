#include "Genie.hpp"
#include "Extern.hpp"
#include "Button.hpp"
#include "Texture.hpp"
#include "Time.hpp"
#include "cmath"
#include "cstring"
#include "cstdlib"
#include "cstdio"

iGenie::iGenie(void) {
    SDL_Init(SDL_INIT_EVERYTHING);

    WindowX = 600;
    WindowY = 300;
    window = SDL_CreateShapedWindow("Genie", WindowX, WindowY, 280, 280, SDL_WINDOW_BORDERLESS);
    rR = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    SDL_Surface *surface = IMG_Load( "black_and_white.png" );
    SDL_Rect srcRect;
    SDL_WindowShapeMode mode;
    mode.mode = ShapeModeColorKey;
    mode.parameters.colorKey.r = 255;
    mode.parameters.colorKey.g = 255;
    mode.parameters.colorKey.b = 255;
    mode.parameters.colorKey.a = 255;
    SDL_Texture *texture=SDL_CreateTextureFromSurface(rR, surface);
    SDL_QueryTexture(texture, NULL, NULL, &srcRect.w, &srcRect.h);
    SDL_SetWindowSize(window, srcRect.w, srcRect.h);
    SDL_SetWindowShape(window, surface, &mode);
    SDL_SetWindowPosition(window, WindowX, WindowY);

    moodPicture[VERTICAL_BOUNCE].Initialize("vertical_bounce", rR, 7);
    moodPicture[HORIZONTAL_BOUNCE].Initialize("horizontal_bounce", rR, 9);
    moodPicture[ROLLING_EYES].Initialize("rolling_eyes", rR, 9);
    moodPicture[ANGRY].Initialize("angry", rR, 16);
    moodPicture[BASKETBALL].Initialize("basketball", rR, 16);
    mood = HORIZONTAL_BOUNCE ;
    motion = false ;

    mainEvent = new SDL_Event();

    srand(time(NULL));
}

iGenie::~iGenie(void) {
    delete mainEvent;
    SDL_DestroyRenderer(rR);
    SDL_DestroyWindow(window);
}

/* ******************************************** 精靈開始 ******************************************** */
void iGenie::mainLoop() {
    iTexture NoEyesGenie("NoEyesGenie", rR);
    iTexture EyesGenie("EyesGenie", rR);
    iButton NoFileButton ("NoFileButton", rR, 0, 0);

    iButton gotoTool1("gotoTool1", rR, 400, 400);
    iButton gotoTool2("gotoTool2", rR, 400, 400);
    iButton gotoTool3("gotoTool3", rR, 400, 400);
    iButton gotoTool4("cross", rR, 400, 400);

    while (1) {
        SDL_RenderClear(rR);
        NoFileButton.setRECT(1, 1, 278, 278);

        if (SDL_PollEvent(mainEvent) != 0) {
            NoFileButton.handleEvent(mainEvent);
        }
        if (NoFileButton.getCurrentState() == MOUSE_OUT){
            if( motion ){
                RandomMove();
            }
            Animation();
        }
        else if (NoFileButton.getCurrentState() == MOUSE_OVER_MOTION) {
            NoEyesGenie.Show(rR, 0, 0, 280, 280);
            RollingEyes();
        }
        else if (NoFileButton.getCurrentState() == MOUSE_UP) {
            while (1) {
                SDL_RenderClear(rR);

                static int j = 0;
                if (j == 0) {
                    for (int i = 0; i <= 100; i++) {
                        SDL_RenderClear(rR);
                        gotoTool1.setRECT(45-i/4, 165-i/4, i/2, i/2);
                        gotoTool2.setRECT(105-i/4, 225-i/4, i/2, i/2);
                        gotoTool3.setRECT(165-i/4, 225-i/4, i/2, i/2);
                        gotoTool4.setRECT(225-i/4, 165-i/4, i/2, i/2);
                        EyesGenie.Show(rR, 0, 0, 280, 280);
                        gotoTool1.Show(rR);
                        gotoTool2.Show(rR);
                        gotoTool3.Show(rR);
                        gotoTool4.Show(rR);
                        SDL_RenderPresent(rR);
                    }
                    j++;
                }

                gotoTool1.setRECT(20, 140, 50, 50);
                gotoTool2.setRECT(80, 200, 50, 50);
                gotoTool3.setRECT(140, 200, 50, 50);
                gotoTool4.setRECT(200, 140, 50, 50);
                NoFileButton.buttonReset();

                if (SDL_PollEvent( mainEvent ) != 0) {
                    gotoTool1.handleEvent(mainEvent);
                    gotoTool2.handleEvent(mainEvent);
                    gotoTool3.handleEvent(mainEvent);
                    gotoTool4.handleEvent(mainEvent);
                    NoFileButton.handleEvent(mainEvent);
                }
                EyesGenie.Show(rR, 0, 0, 280, 280);
                gotoTool1.Show(rR);
                gotoTool2.Show(rR);
                gotoTool3.Show(rR);
                gotoTool4.Show(rR);
                if (NoFileButton.getCurrentState() == MOUSE_UP && gotoTool1.getCurrentState() == MOUSE_OUT && gotoTool2.getCurrentState() == MOUSE_OUT && gotoTool3.getCurrentState() == MOUSE_OUT) {
                    j = 0;
                    break;
                }
                if (gotoTool1.getCurrentState() == MOUSE_UP) {
                    SDL_HideWindow(window);
                    CountDown();
                }
                if (gotoTool2.getCurrentState() == MOUSE_UP) {
                    true_clock();
                }
                if (gotoTool3.getCurrentState() == MOUSE_UP){
                    Timer();
                }
                if (gotoTool4.getCurrentState() == MOUSE_UP ){
                    break;
                }
                SDL_RenderPresent(rR);
            }
            NoFileButton.buttonAdjust();
        }
        if (gotoTool4.getCurrentState() == MOUSE_UP ){
            close();
            break;
        }
        SDL_RenderPresent(rR);
    }
}
/* ********************************************精靈結束******************************************** */

void iGenie::RollingEyes() {
    iTexture LeftEye ("Eye", rR);
    iTexture RightEye("Eye", rR);
    int Lx, Ly; double Langle;
    int Rx, Ry; double Rangle;
    SDL_GetMouseState(&Lx, &Ly);
    std::cout << Lx << " " << Ly << std::endl;
    SDL_GetMouseState(&Rx, &Ry);
    double Ldx = double(Lx);
    double Ldy = double(Ly);
    double Rdx = double(Rx);
    double Rdy = double(Ry);
    if (Ldx == 113.0){
        Langle = (Ldy-86.0>0) ? M_PI/2 : -M_PI/2;
    }
    else {
        Langle = atan(double((Ldy-82.0)/(Ldx-113.0)));
    }
    if (Lx < 113.0){
        Langle = Langle + M_PI;
    }
    if (Rdx == 169.0){
        Rangle = (Rdy-86.0>0) ? M_PI/2 : -M_PI/2;
    }
    else {
        Rangle = atan(double((Rdy-82.0)/(Rdx-169.0)));
    }
    if (Rx < 169.0){
        Rangle = Rangle + M_PI;
    }

    Langle = Langle*180.0/M_PI;
    Rangle = Rangle*180.0/M_PI;
    if ((Lx-113)*(Lx-113)+(Ly-82)*(Ly-82) <= 64){
        LeftEye.Show (rR, Lx-4, Ly-4, 8, 8);
    }
    else {
        LeftEye.Show (rR, 116, 78, 8, 8, Langle, -3, 4);
    }
    if ((Rx-169)*(Rx-169)+(Ry-82)*(Ry-82) <= 64){
        RightEye.Show (rR, Rx-4, Ry-4, 8, 8);
    }
    else {
        RightEye.Show(rR, 172, 78, 8, 8, Rangle, -3, 4);
    }
}

void iGenie::CountDown() {
    const int SCREEN_WIDTH = 300;
    const int SCREEN_HEIGHT = 420;
    const int button_w = 50;
    const int button_h = 50;
    SDL_Window *window_Countdown = NULL;
    SDL_Renderer *rR_Countdown = NULL;
    SDL_Event *mainEvent_Countdown;
    SDL_Init( SDL_INIT_EVERYTHING );
    window_Countdown = SDL_CreateWindow( "Countdown", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
    rR_Countdown = SDL_CreateRenderer( window_Countdown, -1, SDL_RENDERER_ACCELERATED );
    mainEvent_Countdown = new SDL_Event ;

    SDL_RenderClear( rR_Countdown );
    iTexture numbers[11];
    for (int i = 0; i < 10; i++) {
        char temp[2];
        temp[0] = i+'0';
        temp[1] = '\0';
        numbers[i].Load(temp, rR_Countdown);
    }
    numbers[10].Load("10", rR_Countdown);

    iTexture digital_clock("digital_clock", rR_Countdown);
    iButton zero("00", rR_Countdown, 500, 500);
    iButton one("11", rR_Countdown, 499, 500);
    iButton two("22", rR_Countdown, 499, 500);
    iButton three("33", rR_Countdown, 499, 500);
    iButton four("44", rR_Countdown, 499, 500);
    iButton five("55", rR_Countdown, 499, 500);
    iButton six("66", rR_Countdown, 499, 500);
    iButton seven("77", rR_Countdown, 499, 500);
    iButton eight("88", rR_Countdown ,499, 500);
    iButton night("99", rR_Countdown, 499, 500);
    iButton start("CountStart", rR_Countdown, 400, 285);
    iButton reset("CountReset", rR_Countdown, 400, 285);
    iButton pause("CountPause", rR_Countdown, 400, 285);

    zero.setRECT(125, 340, button_w, button_h);
    one.setRECT(38,  160, button_w, button_h);
    two.setRECT(125, 160, button_w, button_h);
    three.setRECT(212, 160, button_w, button_h);
    four.setRECT(38, 220, button_w, button_h);
    five.setRECT(125, 220, button_w, button_h);
    six.setRECT(212, 220, button_w, button_h);
    seven.setRECT(38,  280, button_w, button_h);
    eight.setRECT(125, 280, button_w, button_h);
    night.setRECT(212, 280, button_w, button_h);
    start.setRECT(212, 340, button_w, button_h);
    reset.setRECT(38, 340, button_w, button_h);
    pause.setRECT(212, 340, button_w, button_h);

    iTime digital_time;
    int numbers_set=0, temp=0;
    bool run=false, quit=false;
    time_t t1 ,t2;
    while(!quit){
        SDL_RenderClear(rR_Countdown);
        digital_clock.Show(rR_Countdown, 0, 0, 300, 474);

        if(SDL_PollEvent( mainEvent_Countdown ) != 0){
            zero.handleEvent(mainEvent_Countdown);
            one.handleEvent(mainEvent_Countdown);
            two.handleEvent(mainEvent_Countdown);
            three.handleEvent(mainEvent_Countdown);
            four.handleEvent(mainEvent_Countdown);
            five.handleEvent(mainEvent_Countdown);
            six.handleEvent(mainEvent_Countdown);
            seven.handleEvent(mainEvent_Countdown);
            eight.handleEvent(mainEvent_Countdown);
            night.handleEvent(mainEvent_Countdown);
            start.handleEvent(mainEvent_Countdown);
            reset.handleEvent(mainEvent_Countdown);
            if( mainEvent_Countdown->type == SDL_QUIT ){
                std::cout << "-~-" << std::endl ;
                quit=true;
            }
        }

        int nowNumber = -1;

        if(one.getCurrentState()==MOUSE_UP){nowNumber = 1;}
        else if(two.getCurrentState()==MOUSE_UP){nowNumber = 2;}
        else if(three.getCurrentState()==MOUSE_UP){nowNumber = 3;}
        else if(four.getCurrentState()==MOUSE_UP){nowNumber = 4;}
        else if(five.getCurrentState()==MOUSE_UP){nowNumber = 5;}
        else if(six.getCurrentState()==MOUSE_UP){nowNumber = 6;}
        else if(seven.getCurrentState()==MOUSE_UP){nowNumber = 7;}
        else if(eight.getCurrentState()==MOUSE_UP){nowNumber = 8;}
        else if(night.getCurrentState()==MOUSE_UP){nowNumber = 9;}
        else if(zero.getCurrentState()==MOUSE_UP){nowNumber = 0;}

        if(numbers_set<6 && nowNumber != -1){
            switch(numbers_set){
                case 0:
                    temp=nowNumber;
                    digital_time.SetHour(temp, 0);
                    break;
                case 1:
                    digital_time.SetHour(temp,nowNumber);
                    break;
                case 2:
                    if (nowNumber >= 6) {
                        //audio
                        numbers_set--;
                        break;
                    }
                    temp=nowNumber;
                    digital_time.SetMinute(temp, 0);
                    break;
                case 3:
                    digital_time.SetMinute(temp,nowNumber);
                    break;
                case 4:
                    if (nowNumber >= 6) {
                        //audio
                        numbers_set--;
                        break;
                    }
                    temp=nowNumber;
                    digital_time.SetSecond(temp, 0);
                    break;
                case 5:
                    digital_time.SetSecond(temp,nowNumber);
                    break;
                default:
                    break;
            }
            one.buttonReset();
            two.buttonReset();
            three.buttonReset();
            four.buttonReset();
            five.buttonReset();
            six.buttonReset();
            seven.buttonReset();
            eight.buttonReset();
            night.buttonReset();
            zero.buttonReset();
            numbers_set++;
        }

        if(start.getCurrentState()==MOUSE_UP){
            if(!run){
                run=true;
                numbers_set=6;
                t1=time(NULL);
            }
            else{
                run=false;
            }
            start.buttonReset();
        }

        if(!run && reset.getCurrentState()==MOUSE_UP){
            numbers_set=0;
            digital_time.ResetTime();
        }

        if(run){
            t2=time(NULL);
            digital_time.MinusTime(t2-t1);
            t1=t2;
            if(strcmp(digital_time.GetTime(),"00:00:00")==0){
                run=false;
            }
        }

        int x = 12;
        for (int i = 0; i < 6; i++){
            if(i==numbers_set){
                numbers[0].Show(rR_Countdown, 2+x, 43, 37, 35);
                numbers[10].Show(rR_Countdown, 2+x, 50, 37, 35);
                x+=37;
            }
            else{
                numbers[digital_time.GetTimeDigit(i)].Show(rR_Countdown, x, 43, 37, 35);
                x+=37;
            }
            if(i==1 || i==3){
                x+=27;
            }
        }

        one.Show(rR_Countdown);
        two.Show(rR_Countdown);
        three.Show(rR_Countdown);
        four.Show(rR_Countdown);
        five.Show(rR_Countdown);
        six.Show(rR_Countdown);
        seven.Show(rR_Countdown);
        eight.Show(rR_Countdown);
        night.Show(rR_Countdown);
        zero.Show(rR_Countdown);
        start.Show(rR_Countdown);
        reset.Show(rR_Countdown);

        if(!run){
            start.Show(rR_Countdown);
        }
        else{
            pause.Show(rR_Countdown);
        }
        reset.Show(rR_Countdown);
        SDL_RenderPresent(rR_Countdown);
    }
    SDL_DestroyRenderer(rR_Countdown);
    SDL_DestroyWindow(window_Countdown);
    window_Countdown = NULL;
    rR_Countdown = NULL;
    IMG_Quit();
    SDL_Quit();
}

void iGenie::true_clock(){
    struct tm* ptr_INIT;
    time_t iTime_INIT;

    clock_t endTime;
    struct tm* ptr;
    time_t iTime;

    SDL_Event* mainEvent_TrueClock;
    SDL_Window* window_TrueClock;
    SDL_Renderer* rR_TrueClock;

    mainEvent_TrueClock = new SDL_Event();
    window_TrueClock = SDL_CreateWindow("true_clock", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 600, 600, SDL_WINDOW_BORDERLESS);
    rR_TrueClock = SDL_CreateRenderer(window_TrueClock, -1, SDL_RENDERER_ACCELERATED);
    SDL_Init(SDL_INIT_EVERYTHING);

    iTexture TrueClock("TrueClock", rR_TrueClock);
    iTexture hour_hand("hour_hand", rR_TrueClock);
    iTexture minute_hand("minute_hand" , rR_TrueClock);
    iTexture second_hand("second_hand", rR_TrueClock);
    iButton  LeaveTrueClock("LeaveTrueClock", rR_TrueClock, 300, 300);
    LeaveTrueClock.setRECT(0, 0, 0, 0);

    iTime_INIT = time (NULL);
    ptr_INIT = localtime(&iTime_INIT);
    asctime(ptr_INIT);
    char *Generate = asctime(ptr_INIT);
    char Date_information_INIT[25];
    double Date_information_INIT_number[3];


    while (1){
        while( SDL_PollEvent( mainEvent_TrueClock ) != 0 ){
            LeaveTrueClock.handleEvent(mainEvent_TrueClock);
        }
        if (LeaveTrueClock.getCurrentState() == MOUSE_UP){
            break;
        }

        SDL_RenderClear(rR_TrueClock);

        iTime = time(NULL);
        ptr = localtime (&iTime);
        asctime(ptr);
        endTime = SDL_GetTicks()+1*1000;
        while (SDL_GetTicks()<endTime){};
        strcpy(Date_information_INIT, Generate);
        Date_information_INIT_number[0] = (Generate[11]-'0')*10.0+(Generate[12]-'0');
        Date_information_INIT_number[1] = (Generate[14]-'0')*10.0+(Generate[15]-'0');
        Date_information_INIT_number[2] = (Generate[17]-'0')*10.0+(Generate[18]-'0');

        TrueClock.Show(rR_TrueClock, 0, 0, 600, 600);
        second_hand.Show( rR_TrueClock, 294, 58, 12, 250, (360*Date_information_INIT_number[2]/60), 8, 242  );
        minute_hand.Show( rR_TrueClock, 295, 105, 10, 200, (360*Date_information_INIT_number[1]/60+Date_information_INIT_number[2]*1/10), 5, 195 );
        if (Date_information_INIT_number[0]>=12){
            Date_information_INIT_number[0]=Date_information_INIT_number[0]-12;
        };
        hour_hand.Show( rR_TrueClock, 290, 155, 20, 150, (Date_information_INIT_number[0]/12*360+Date_information_INIT_number[1]*30/60+Date_information_INIT_number[2]*30/3600), 10, 145 );

        SDL_RenderPresent(rR_TrueClock);
    }
    SDL_DestroyRenderer(rR_TrueClock);
    SDL_DestroyWindow(window_TrueClock);
    window_TrueClock = NULL;
    window_TrueClock = NULL;
    IMG_Quit();
    SDL_Quit();
}

void iGenie::Timer() {
    const int SCREEN_WIDTH = 300;
    const int SCREEN_HEIGHT = 210;
    const int button_w = 50;
    const int button_h = 50;
    SDL_Window *window_Timer = NULL;
    SDL_Renderer *rR_Timer = NULL;
    SDL_Event *mainEvent_Timer;
    SDL_Init( SDL_INIT_EVERYTHING );
    window_Timer = SDL_CreateWindow( "Timer", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
    rR_Timer = SDL_CreateRenderer( window_Timer, -1, SDL_RENDERER_ACCELERATED );
    mainEvent_Timer = new SDL_Event ;

    SDL_RenderClear( rR_Timer );
    iTexture numbers[11];
    for (int i = 0; i < 10; i++) {
        char temp[2];
        temp[0] = i+'0';
        temp[1] = '\0';
        numbers[i].Load(temp, rR_Timer);
    }
    numbers[10].Load("10", rR_Timer);

    iTexture digital_clock("counter_background", rR_Timer);
    iButton start("CountStart", rR_Timer, 400, 285);
    iButton reset("CountReset", rR_Timer, 400, 285);
    iButton pause("CountPause", rR_Timer, 400, 285);

    start.setRECT(212, 150, button_w, button_h);
    reset.setRECT(38, 150, button_w, button_h);
    pause.setRECT(212, 150, button_w, button_h);

    iTime digital_time;
    bool run=false, quit=false;
    time_t t1 ,t2;
    while(!quit){
        SDL_RenderClear(rR_Timer);
        digital_clock.Show(rR_Timer, 0, 0, 300, 210);

        if(SDL_PollEvent( mainEvent_Timer ) != 0){
            start.handleEvent(mainEvent_Timer);
            reset.handleEvent(mainEvent_Timer);
            if( mainEvent_Timer->type == SDL_QUIT ){
                std::cout << "-~-" << std::endl ;
                quit=true;
            }
        }
        if(start.getCurrentState()==MOUSE_UP){
            if(!run){
                run=true;
                t1=time(NULL);
            }
            else{
                run=false;
            }
            start.buttonReset();
        }

        if(!run && reset.getCurrentState()==MOUSE_UP){
            digital_time.ResetTime();
        }

        if(run){
            t2=time(NULL);
            digital_time.PlusTime(t2-t1);
            t1=t2;
        }

        int x = 19;
        for (int i = 0; i < 6; i++){
            numbers[digital_time.GetTimeDigit(i)].Show(rR_Timer, x, 60, 37, 35);
            x+=37;
            if(i==1 || i==3){
                x+=20;
            }
        }

        start.Show(rR_Timer);
        reset.Show(rR_Timer);

        if(!run){
            start.Show(rR_Timer);
        }
        else{
            pause.Show(rR_Timer);
        }
        reset.Show(rR_Timer);
        SDL_RenderPresent(rR_Timer);
    }
    SDL_DestroyRenderer(rR_Timer);
    SDL_DestroyWindow(window_Timer);
    window_Timer = NULL;
    rR_Timer = NULL;
    IMG_Quit();
    SDL_Quit();
}

void iGenie::RandomMove() {
    static int i = 0;
    if( i%10 != 0 ){
        i++;
        return ;
    }

    static int _x;
    static int _y;
    if( i == 0 ){
        _x = (rand()%8)-4;
        _y = (rand()%8)-4;
    }
    SDL_DisplayMode screen;
    SDL_GetDesktopDisplayMode( 0, &screen );
    if( WindowX+_x>=0 && WindowX+_x<=screen.w-280 && WindowY+_y>=0 && WindowY+_y<=screen.h-280 ){
        WindowX += _x;
        WindowY += _y;
        SDL_SetWindowPosition(window, WindowX, WindowY);
        i++;
        if (i > 1000) i = 0;
    }
    else{
        i=0;
    }
}

void iGenie::Drag(iButton* NoFileButton) {
    if (NoFileButton->getCurrentState() == MOUSE_DOWN) DragMode = true;
    static int PastX, PastY;
    if (DragMode == false) SDL_GetMouseState(&PastX, &PastY);
    static int NowX, NowY;
    SDL_GetMouseState(&NowX, &NowY);
    if (DragMode == true) {
        if (NowX > PastX)
            SDL_SetWindowPosition(window, WindowX, WindowY);
        else if (NowX < PastX)
            SDL_SetWindowPosition(window, WindowX, WindowY);
        if (NowY > PastY)
            SDL_SetWindowPosition(window, WindowX, WindowY);
        else if (NowY < PastY)
            SDL_SetWindowPosition(window, WindowX, WindowY);
    }
    PastX = NowX;
    PastY = NowY;
    if (NoFileButton->getCurrentState() == MOUSE_UP) DragMode = false;
}

void iGenie::Animation() {
    static int i = 0;
    if (i == 30*moodPicture[mood].getTotalClip()-1 ){
        i = 0;
        motion = rand()%2==0?true:false ;
        if( motion ){
            mood = rand()%2 ;
        }
        else{
            mood = rand()%3 + 2 ;
        }
        std::cout << mood << std::endl ;
    }
    SDL_RenderCopy(rR, moodPicture[mood].getTexture(), &moodPicture[mood].getClip()[i/30], NULL);
    i++;
}

void iGenie::close() {
    SDL_DestroyRenderer(rR);
    SDL_DestroyWindow(window);
    window = NULL;
    rR = NULL;
    IMG_Quit();
    SDL_Quit();
}
