#ifndef Music_hpp
#define Music_hpp

#include <SDL_mixer.h>
#include <iostream>
#include <cstring>

class iMusic {
public:
    iMusic(std::string);
    ~iMusic();
    void PlayMusic(int);

private:
    Mix_Music* gMusic;
    bool radioOn = false;
};

#endif /* Music_hpp */
