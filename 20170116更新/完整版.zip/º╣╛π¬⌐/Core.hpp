#ifndef Core_hpp
#define Core_hpp

#include "SDL.h"
#include "SDL_image.h"

class iCore {
private:
    SDL_Window* window;
    SDL_Renderer* rR;
    SDL_Event* mainEvent;
    bool quitGame;
    
    void close();

public:
    iCore(void);
    ~iCore(void);
    void mainLoop();
};

#endif /* Core_hpp */
