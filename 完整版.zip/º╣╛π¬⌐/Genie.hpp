#ifndef Genie_hpp
#define Genie_hpp

#include "SDL.h"
#include "SDL_image.h"
#include <SDL_shape.h>
#include <SDL_pixels.h>
#include <iostream>
#include "Button.hpp"
#include "Extern.hpp"

enum iMood {
    VERTICAL_BOUNCE = 0,
    HORIZONTAL_BOUNCE = 1,
    ROLLING_EYES = 2,
    ANGRY = 3,
    BASKETBALL = 4,
    MOOD_NUM = 5
};

class iGenie {
private:
    SDL_Window* window;
    SDL_Renderer* rR;
    SDL_Event* mainEvent;
    bool DragMode = false;
    bool motion;
    int WindowX;
    int WindowY;
    iTexture moodPicture[ MOOD_NUM ];
    int mood;

public:
    iGenie(void);
    ~iGenie(void);

    void mainLoop();
    void RollingEyes();
    void CountDown();
    void true_clock();
    void Timer();
    void Drag(iButton*);
    void RandomMove();
    void Animation();
    void close();
};


#endif
