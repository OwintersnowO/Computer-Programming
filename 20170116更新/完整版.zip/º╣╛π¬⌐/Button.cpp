#include "Button.hpp"

void iButton::handleEvent( SDL_Event* e )
{
        int x, y;
        SDL_GetMouseState( &x, &y );
    
        bool inside = true;
        
        if( x < rRect.x ) {
            inside = false;
        }
        else if( x > rRect.x + rRect.w - 1 ) {
            inside = false;
        }
        else if( y < rRect.y ) {
            inside = false;
        }
        else if( y > rRect.y + rRect.h - 1 ) {
            inside = false;        }
        
        if( !inside ) {
            bCurrentState = MOUSE_OUT;
        }
        
        else
        {
            switch( e->type )
            {
                case SDL_MOUSEBUTTONDOWN:
                    bCurrentState = MOUSE_DOWN;
                    break;
                    
                case SDL_MOUSEBUTTONUP:
                    bCurrentState = MOUSE_UP;
                    break;
                    
                default:
                    bCurrentState = MOUSE_OVER_MOTION;
                    break;
            }
        }
}

void iButton::Show(SDL_Renderer* rR, int x, int y, int w, int h) {
    setRECT(x, y, w, h);
    iTexture::Show(rR, bCurrentState);
}

void iButton::buttonReset() {
    bCurrentState = MOUSE_OUT;
}

void iButton::buttonAdjust() {
    bCurrentState = MOUSE_OVER_MOTION;
}

int iButton::getCurrentState() {
    return bCurrentState;
}
