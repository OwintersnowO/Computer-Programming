#include "Extern.hpp"

int iExtern::GENIE_WIDTH  = 291;
int iExtern::GENIE_HEIGHT = 291;

int iExtern::MENU_WIDTH = 400;
int iExtern::MENU_HEIGHT = 400;
