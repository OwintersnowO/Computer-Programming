#include "Core.hpp"
#include "Genie.hpp"
#include "Texture.hpp"
#include "Button.hpp"

iCore::iCore(void) {
    quitGame= false;

    SDL_Init(SDL_INIT_VIDEO);

    window = SDL_CreateWindow("Core", 200, 200, 400, 400, SDL_WINDOW_BORDERLESS);

    rR = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

    mainEvent = new SDL_Event();
}

iCore::~iCore() {}

/* ********************************************首頁******************************************** */
void iCore::mainLoop() {
    iTexture background("background", rR);
    iTexture cloudRightUp("cloudRightUp", rR);
    iTexture cloudRightDown("cloudRightDown", rR);
    iTexture cloudLeft("cloudLeft", rR);
    iButton  gotoChooseGenie("gotoChooseGenie", rR, 304, 125);
    iButton  gotoHelp("gotoHelp", rR, 305, 125);
    iButton  Leave("Leave", rR, 306, 125);
    iTexture Help("Help", rR);
    iButton  backtoMenu("backtoMenu", rR, 422, 125);
    iButton  gotoTimeGenie("gotoTimeGenie", rR, 303, 125);
    iButton  gotoMoneyGenie("gotoMoneyGenie", rR, 303, 125);
    iButton  gotoWeatherGenie("gotoMoneyGenie", rR, 303, 125);

    while(!quitGame) {
        SDL_RenderClear(rR);

        static int i = -1;
        if (i == -1) {
            for (int j = 0; j <= 1120; j++) {
                SDL_RenderClear(rR);
                background.Show(rR, 0, 0, 400, 400);
                cloudLeft.Show(rR, -100+j/10, 100, 150, 30);
                cloudRightUp.Show(rR, 350-j/20, 20, 60, 30);
                cloudRightDown.Show(rR, 380-j/10, 100, 130, 30);
                gotoChooseGenie.Show(rR, 100, 400-j/4, 200, 80);
                SDL_RenderPresent(rR);
            }
            i++;
        }

        if (i == 0) {
            gotoChooseGenie.setAlpha(0);
            gotoHelp.setAlpha(0);
            Leave.setAlpha(0);
        }
        if (i < 64) {
            gotoChooseGenie.setAlpha(i*4);
            i++;
        }
        else if (i < 128) {
            gotoHelp.setAlpha(i*4-256);
            i++;
        }
        else if (i < 192) {
            Leave.setAlpha(i*4-512);
            i++;
        }

        while(SDL_PollEvent( mainEvent ) != 0) {
            gotoChooseGenie.handleEvent(mainEvent);
            gotoHelp.handleEvent(mainEvent);
            Leave.handleEvent(mainEvent);
        }
        background.Show(rR, 0, 0, 400, 400);
        cloudLeft.Show(rR, 12, 100, 150, 30);
        cloudRightUp.Show(rR, 294, 20, 60, 30);
        cloudRightDown.Show(rR, 268, 100, 130, 30);
        Leave.Show(rR, 100, 280, 200, 80);
        gotoHelp.Show(rR, 100, 200, 200, 80);
        gotoChooseGenie.Show(rR, 100, 120, 200, 80);
/* ********************************************進入選擇精靈介面******************************************** */
        if (gotoChooseGenie.getCurrentState() == MOUSE_UP && i == 192) {
            i = 0;
            gotoTimeGenie.buttonAdjust();

            while (1) {
                SDL_RenderClear(rR);

                if (i == 0) {
                    gotoTimeGenie.setAlpha(0);
                    gotoMoneyGenie.setAlpha(0);
                    gotoWeatherGenie.setAlpha(0);
                    i++;
                }
                if (i < 64) {
                    gotoTimeGenie.setAlpha(i*4);
                    i++;
                }
                else if (i < 128) {
                    gotoMoneyGenie.setAlpha(i*4-256);
                    i++;
                }
                else if (i < 192) {
                    gotoWeatherGenie.setAlpha(i*4-512);
                    i++;
                }

                while(SDL_PollEvent( mainEvent ) != 0) {
                    gotoTimeGenie.handleEvent(mainEvent);
                    gotoMoneyGenie.handleEvent(mainEvent);
                    gotoWeatherGenie.handleEvent(mainEvent);
                }

                background.Show(rR, 0, 0, 400, 400);
                cloudLeft.Show(rR, 12, 100, 150, 30);
                cloudRightUp.Show(rR, 294, 20, 60, 30);
                cloudRightDown.Show(rR, 268, 100, 130, 30);
                gotoTimeGenie.Show(rR, 100, 120, 200, 80);
                gotoMoneyGenie.Show(rR, 100, 200, 200, 80);
                gotoWeatherGenie.Show(rR, 100, 280, 200, 80);

                if (gotoTimeGenie.getCurrentState() == MOUSE_OUT && gotoMoneyGenie.getCurrentState() == MOUSE_OUT && gotoWeatherGenie.getCurrentState() == MOUSE_OUT) {
                    i = 0;
                    break;
                }

                if (gotoTimeGenie.getCurrentState() == MOUSE_UP) {
                    close();
                    iGenie Timegenie;
                    Timegenie.mainLoop();
                    break;
                }

                SDL_RenderPresent(rR);
            }
        }
        if(gotoTimeGenie.getCurrentState()==MOUSE_UP){
            break;
        }
/* ********************************************退出選擇精靈介面******************************************** */
        else if (gotoHelp.getCurrentState() == MOUSE_UP) {
            while(1) {
                SDL_RenderClear(rR);
                while(SDL_PollEvent( mainEvent ) != 0) {
                    backtoMenu.handleEvent(mainEvent);
                }

                Help.Show(rR, 0, 0, 400, 400);
                backtoMenu.Show(rR, 250, 350, 150, 40);

                if (backtoMenu.getCurrentState() == MOUSE_UP) {
                    break;
                }
                SDL_RenderPresent(rR);
            }
            gotoHelp.buttonReset();
            backtoMenu.buttonReset();
        }
        else if (Leave.getCurrentState() == MOUSE_UP) {
            close();
            break;
        }
        backtoMenu.buttonReset();
        SDL_RenderPresent(rR);
    }
}
/* ********************************************首頁******************************************** */

void iCore::close() {
    SDL_DestroyRenderer(rR);
    SDL_DestroyWindow(window);
    window = NULL;
    rR = NULL;
    IMG_Quit();
    SDL_Quit();
}
