#include "Music.hpp"

iMusic::iMusic(std::string fileName) {
    fileName = "/Users/han0110/Desktop/Ceiba/計算機程式/iGroc/music/" + fileName + ".mp3";
    gMusic = Mix_LoadMUS(fileName.c_str());
}

iMusic::~iMusic() {
    Mix_FreeMusic(gMusic);
    Mix_Quit();
}

void iMusic::PlayMusic(int loopTime) {
    Mix_PlayMusic(gMusic, loopTime);
}
