#include "Core.hpp"
#undef _WIN32_WINNT
#define _WIN32_WINNT 0x0500
#include<windows.h>

int main(int argc, char * argv[]) {
    ShowWindow( GetConsoleWindow(), SW_HIDE );
    iCore iGroc;
    iGroc.mainLoop();

    return 0;
}
