#ifndef iExtern_hpp
#define iExtern_hpp
#include <SDL.h>

class iExtern {
public:
    static int GENIE_WIDTH, GENIE_HEIGHT;
    static int MENU_WIDTH, MENU_HEIGHT;
};


#endif /* iExtern_hpp */
