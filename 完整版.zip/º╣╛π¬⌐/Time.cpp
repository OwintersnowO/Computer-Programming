#include "Time.hpp"

iTime::iTime() {
    ResetTime();
}
iTime::~iTime() {}

void iTime::SetHour(int tens, int ones){
    format[0]=tens+'0';
    format[1]=ones+'0';
    hour=tens*10+ones;
    return ;
}
void iTime::SetMinute(int tens, int ones){
    format[3]=tens+'0';
    format[4]=ones+'0';
    minute=tens*10+ones;
    return ;
}
void iTime::SetSecond(int tens, int ones){
    format[6]=tens+'0';
    format[7]=ones+'0';
    second=tens*10+ones;
    return ;
}
void iTime::ResetTime(){
    format[0]='0';
    format[1]='0';
    format[2]=':';
    format[3]='0';
    format[4]='0';
    format[5]=':';
    format[6]='0';
    format[7]='0';
    format[8]='\0';
    hour=0;
    minute=0;
    second=0;
    return ;
}
char* iTime::GetTime(){
    return format;
}
int iTime::GetTimeDigit(int i){
    switch(i){
        case 0:
            return format[0]-'0';
        case 1:
            return format[1]-'0';
        case 2:
            return format[3]-'0';
        case 3:
            return format[4]-'0';
        case 4:
            return format[6]-'0';
        case 5:
            return format[7]-'0';
        default:
            return 0;
    }
}
void iTime::MinusTime(long temp){
    second-=temp;
    if(second<0){
        minute-=(60-second)/60;
        second=second%60+60;
    }
    if(minute<0){
        hour-=(60-minute)/60;
        minute=minute%60+60;
    }
    if(hour<0){
        hour=0;
    }
    SetHour(hour/10,hour%10);
    SetMinute(minute/10,minute%10);
    SetSecond(second/10,second%10);
    return ;
}

void iTime::PlusTime(long temp){
    second+=temp;
    if(second>=60){
        minute+=second/60;
        second%=60;
    }
    if(minute>=60){
        hour+=minute/60;
        minute%=60;
    }
    if(hour>99){
        hour=99;
    }
    SetHour(hour/10,hour%10);
    SetMinute(minute/10,minute%10);
    SetSecond(second/10,second%10);
    return ;
}
