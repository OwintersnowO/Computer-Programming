#ifndef Time_hpp
#define Time_hpp
#include <string>
#include <ctime>

class iTime{
public:
    iTime();
    ~iTime();
    void SetHour(int tens, int ones);
    void SetMinute(int tens, int ones);
    void SetSecond(int tens, int ones);
    void ResetTime();
    char* GetTime();
    int GetTimeDigit(int);
    void MinusTime(long temp);
    void PlusTime(long temp);

private:
    char format[9];
    int hour;
    int minute;
    int second;
};

#endif /* Time_hpp */
